/* cpnpc.c--Cyberpunk NPC generator version 1.1--Todd Bradley      */
/* See end of file for copyright and version notifications           */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "cpnpc.h"

/* These are global variables for the total number of types
	of each Role the user wants */

int numsolo = 0, numnomad = 0, numrocker  = 0, numnetrunner = 0;
int numcorp = 0, numtech  = 0, nummedtech = 0, nummedia     = 0;
int numcop  = 0, numfixer = 0, numthug    = 0;

int Int, Ref, Tech, Cool, Attr, Luck, MA, Body, Emp;

int main(int argc, char *argv[])
{
	int i, total;
	time_t t;

	if (argc < 1) help();

/* Process the command */
	for (i=1; i<argc; i++)
	{
		if (strlen(argv[i]) > 3) help();

/* Count how many of each character class you want */
	countargs(argv[i]);
	}

	total = numsolo + numnomad + numrocker + numnetrunner
		+ numcorp + numtech + nummedtech + nummedia
		+ numcop + numfixer + numthug;

	if (total == 0) help();

/* Echo back how many of each class were requested */
	fprintf(stdout, "\nThe following characters will be made:");
	if (numsolo > 0)	printf("\nSolos = %d", numsolo);
	if (numnomad > 0)	printf("\nNomads = %d", numnomad);
	if (numrocker > 0)	printf("\nRockers = %d", numrocker);
	if (numnetrunner > 0)	printf("\nNetrunners = %d", numnetrunner);
	if (numcorp > 0)	printf("\nCorporates = %d", numcorp);
	if (numtech > 0)	printf("\nTechies = %d", numtech);
	if (nummedtech > 0)	printf("\nMedtechies = %d", nummedtech);
	if (nummedia > 0)	printf("\nMedias = %d", nummedia);
	if (numcop > 0)		printf("\nCops = %d", numcop);
	if (numfixer > 0)	printf("\nFixers = %d", numfixer);
	if (numthug > 0)	printf("\nThugs = %d", numthug);

	printf("\n\n");

/* Initialize the randomizer */
	srand((unsigned) time(&t));

/* Get down to business.  Process the requested NPC's */
	for (i = 0; i < numsolo; i++) makechar(SOLO);
	for (i = 0; i < numnomad; i++) makechar(NOMAD);
	for (i = 0; i < numrocker; i++) makechar(ROCKER);
	for (i = 0; i < numnetrunner; i++) makechar(NETRUNNER);
	for (i = 0; i < numcorp; i++) makechar(CORP);
	for (i = 0; i < numtech; i++) makechar(TECHIE);
	for (i = 0; i < nummedtech; i++) makechar(MEDTECH);
	for (i = 0; i < nummedia; i++) makechar(MEDIA);
	for (i = 0; i < numcop; i++) makechar(COP);
	for (i = 0; i < numfixer; i++) makechar(FIXER);
	for (i = 0; i < numthug; i++) makechar(THUG);

	return(0);
}

int makechar(int roleint)

/* This routine does most of the work of generating the NPC */

{
	int points, numcyberware, i, typenumber, itemnumber;
	int armor, weapon, btm, drug;
	char *item, *type, *cyberware[8];

	printf("\nName:\t\t\t\tRole: ");
	printrole(roleint);
	if (d6() < 4)
		printf("\tSex: Female\n");
	else
		printf("\tSex: Male\n");


/* Calculate the ability scores randomly */
	Int  = d6() + d6();
	Ref  = d6() + d6();
	Tech = d6() + d6();
	Cool = d6() + d6();
	Attr = d6() + d6();
	Luck = d6() + d6();
	MA   = d6() + d6();
	Body = d6() + d6();
	Emp  = d6() + d6();

 /* Modify abilities for Role */
	switch (roleint) {
		case SOLO: Body++; Int--; Ref++; Attr--; break;
		case NOMAD: Ref++; Cool++; Luck--; Int--; break;
		case ROCKER: Ref++; Attr++; Int--; MA--; break;
		case NETRUNNER: Ref++; Int++; Body--; MA--; break;
		case CORP: Int++; Luck++; Tech--; Body--; break;
		case TECHIE: Int++; Tech++; Body--; MA--; break;
		case MEDTECH: Int++; Tech++; Body--; MA--; break;
		case MEDIA: Emp++; Attr++; Body--; Tech--; break;
		case COP: Cool++; Ref++; Tech--; Attr--; break;
		case FIXER: Int++; Cool++; MA--; Tech--; break;
		case THUG: Body++; Int--; Ref++; Attr--; break;
	}

	checkstats();

/* Print out ability scores */
	printf("\nAbilities:\n");
	printf("Int:  %d \t", Int);
	printf("Ref:  %d \t", Ref);
	printf("Tech: %d \t", Tech);
	printf("Cool: %d \t", Cool);
	printf("Attr: %d \n", Attr);
	printf("Luck: %d \t", Luck);
	printf("MA:   %d \t", MA);
	printf("Body: %d \t", Body);
	printf("Emp:  %d \t", Emp);


	printf("\n\nSkills:\n");

/* Generate skill list from package */
	points = 40;
	switch (roleint) {
	case SOLO:
		printf("Cbt. Sense: %d \t", skillnum(&points, 10));
		printf("Awareness:  %d \t", skillnum(&points, 10));
		printf("Handgun:    %d \t", skillnum(&points, 8));
		printf("Athletics:  %d \n", skillnum(&points, 8));
		printf("Rifle:      %d \t", skillnum(&points, 8));
		if (d6() < 5)
			printf("Mart'l Art: %d \t", skillnum(&points, 8));
		else
			printf("Brawling:   %d \t", skillnum(&points, 10));
		printf("Melee:      %d \t", skillnum(&points, 10));
		printf("Stealth:    %d \n", skillnum(&points, 8));
		printf("SMG:        %d \t", skillnum(&points, 8));
		break;
	case NOMAD:
		printf("Family:     %d \t", skillnum(&points, 10));
		printf("Drive:      %d \t", skillnum(&points, 8));
		printf("Brawling:   %d \t", skillnum(&points, 10));
		printf("Athletics:  %d \n", skillnum(&points, 10));
		printf("Melee:      %d \t", skillnum(&points, 8));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		printf("Rifle:      %d \t", skillnum(&points, 10));
		printf("Survival:   %d \n", skillnum(&points, 8));
		printf("Basic Tech: %d \t", skillnum(&points, 8));
		printf("Endurance:  %d \t", skillnum(&points, 8));
		break;
	case ROCKER:
		printf("Cha. Lead.: %d \t", skillnum(&points, 10));
		printf("Perform:    %d \t", skillnum(&points, 8));
		printf("Play Inst.: %d \t", skillnum(&points, 8));
		printf("Streetwise: %d \n", skillnum(&points, 10));
		printf("Wardrobe:   %d \t", skillnum(&points, 8));
		printf("Compose:    %d \t", skillnum(&points, 8));
		printf("Persuasion: %d \t", skillnum(&points, 8));
		printf("Brawling:   %d \n", skillnum(&points, 5));
		printf("Seduction:  %d \t", skillnum(&points, 8));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		break;
	case NETRUNNER:
		printf("Interface:  %d \t", skillnum(&points, 10));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		printf("Sys. Know.: %d \t", skillnum(&points, 8));
		printf("Education:  %d \n", skillnum(&points, 10));
		printf("Program.:   %d \t", skillnum(&points, 8));
		printf("CyberTech:  %d \t", skillnum(&points, 8));
		printf("BasicTech:  %d \t", skillnum(&points, 8));
		printf("Electr.:    %d \n", skillnum(&points, 5));
		printf("Cyberdeck:  %d \t", skillnum(&points, 8));
		printf("Compose:    %d \t", skillnum(&points, 8));
		break;
	case CORP:
		printf("Resources:  %d \t", skillnum(&points, 10));
		printf("Education:  %d \t", skillnum(&points, 10));
		printf("Human Per.: %d \t", skillnum(&points, 10));
		printf("Persuasion: %d \n", skillnum(&points, 8));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		printf("Social:     %d \t", skillnum(&points, 8));
		printf("Stock Mkt:  %d \t", skillnum(&points, 5));
		printf("Library:    %d \n", skillnum(&points, 8));
		printf("Wardrobe:   %d \t", skillnum(&points, 8));
		printf("Grooming:   %d \t", skillnum(&points, 10));
		break;
	case TECHIE:
		printf("Jury Rig:   %d \t", skillnum(&points, 10));
		printf("Basic Tech: %d \t", skillnum(&points, 10));
		printf("Education:  %d \t", skillnum(&points, 10));
		printf("Cyber Tech: %d \n", skillnum(&points, 8));
		printf("Electronic: %d \t", skillnum(&points, 8));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		printf("Gyro Tech:  %d \t", skillnum(&points, 8));
		printf("Aero Tech:  %d \n", skillnum(&points, 8));
		printf("Wpn Tech:   %d \t", skillnum(&points, 8));
		printf("Elec. Sec.: %d \t", skillnum(&points, 8));
		break;
	case MEDTECH:
		printf("Med Tech:   %d \t", skillnum(&points, 10));
		printf("Diagnose:   %d \t", skillnum(&points, 10));
		printf("Education:  %d \t", skillnum(&points, 10));
		printf("Basic Tech: %d \n", skillnum(&points, 8));
		printf("Cryotank:   %d \t", skillnum(&points, 8));
		printf("Pharmacy:   %d \t", skillnum(&points, 5));
		printf("Human Per.: %d \t", skillnum(&points, 8));
		printf("Awareness:  %d \n", skillnum(&points, 8));
		printf("Library:    %d \t", skillnum(&points, 10));
		printf("Zoology:    %d \t", skillnum(&points, 8));
	case MEDIA:
		printf("Credible:   %d \t", skillnum(&points, 10));
		printf("Interview:  %d \t", skillnum(&points, 8));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		printf("Human Per.: %d \n", skillnum(&points, 8));
		printf("Streetwise: %d \t", skillnum(&points, 7));
		printf("Persuasion: %d \t", skillnum(&points, 8));
		printf("Photo/Film: %d \t", skillnum(&points, 8));
		printf("Education:  %d \n", skillnum(&points, 10));
		printf("Compose:    %d \t", skillnum(&points, 8));
		printf("Social:     %d \t", skillnum(&points, 8));
		break;
	case COP:
		printf("Authority:  %d \t", skillnum(&points, 10));
		printf("Handgun:    %d \t", skillnum(&points, 10));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		printf("Athletics:  %d \n", skillnum(&points, 10));
		printf("Human Per.: %d \t", skillnum(&points, 8));
		printf("Melee:      %d \t", skillnum(&points, 8));
		printf("Brawling:   %d \t", skillnum(&points, 8));
		printf("Education:  %d \n", skillnum(&points, 8));
		printf("Interrog.:  %d \t", skillnum(&points, 8));
		printf("Streetwise: %d \t", skillnum(&points, 8));
		break;
	case FIXER:
		printf("Streetdeal: %d \t", skillnum(&points, 10));
		printf("Awareness:  %d \t", skillnum(&points, 8));
		printf("Persuasion: %d \t", skillnum(&points, 10));
		printf("Handgun:    %d \n", skillnum(&points, 9));
		printf("Melee:      %d \t", skillnum(&points, 9));
		printf("Forgery:    %d \t", skillnum(&points, 10));
		printf("Pick Lock:  %d \t", skillnum(&points, 8));
		printf("Pickpocket: %d \n", skillnum(&points, 8));
		printf("Intimidate: %d \t", skillnum(&points, 8));
		printf("Brawling:   %d \t", skillnum(&points, 8));
		break;
	case THUG:
		printf("Cbt. Sense: %d \t", skillnum(&points, 10));
		printf("Awareness:  %d \t", skillnum(&points, 10));
		printf("Handgun:    %d \t", skillnum(&points, 8));
		printf("Brawling:   %d \n", skillnum(&points, 10));
		printf("Melee:      %d \t", skillnum(&points, 10));
		printf("Athletics:  %d \t", skillnum(&points, 8));
		printf("Rifle:      %d \t", skillnum(&points, 8));
		printf("Stealth:    %d \n", skillnum(&points, 8));
		printf("SMG:        %d \t", skillnum(&points, 8));
		break;
	}

/* Now, the pickup skills */
	points = points + Ref + Int;
	printf("Pickup Skills: %d points\n\n", points);

/* Determine Cyberware */
	if (roleint == SOLO)
		numcyberware =  d6() + 2;
	else
		numcyberware = d6();
	for (i = 0; i < numcyberware; i++)
	{
		item = " ";
		type = " ";
		itemnumber = rand() % 15 + 1;

		switch (itemnumber) {
			case 1:	item = "Cyberoptics--";
				typenumber = d10();
				switch (typenumber) {
					case 1:  type = "ImageEnhance "; break;
					case 2:	 type = "Lowlight     "; break;
					case 3:  type = "Camera       "; break;
					case 4:	 type = "Dartgun      "; break;
					case 5:  type = "Antidazzle   "; break;
					case 6:  type = "Target scope "; break;
					case 7:  type = "Teleoptics   "; break;
					case 8:  type = "Dartgun      "; break;
					case 9:  type = "Thermograph  "; break;
					case 10: type = "Micro-optics "; break;
				}
				break;
			case 2:	item = "Cyberarm-----";
				typenumber = d6();
				switch (typenumber) {
					case 1: type = "Med. Pistol  "; break;
					case 2: type = "Light Pistol "; break;
					case 3: type = "Med. Pistol  "; break;
					case 4: type = "Light SMG    "; break;
					case 5: type = "V.Hvy Pistol "; break;
					case 6: type = "Heavy Pistol "; break;
				}
				break;
			case 3: item = "Cyberaudio---";
				typenumber = d10();
				switch (typenumber) {
					case 1:  type = "Wearman      "; break;
					case 2:  type = "Radio Link   "; break;
					case 3:  type = "Phone Splice "; break;
					case 4:  type = "Amp. Hearing "; break;
					case 5:  type = "Sound Edit   "; break;
					case 6:  type = "Digital Rec. "; break;
					case 7:  type = "VoiceAnalyze "; break;
					case 8:  type = "Wearman      "; break;
					case 9:  type = "Scrambler    "; break;
					case 10: type = "Enh. Range   "; break;
				}
				break;
			case 4: item = "Big Knucks                "; break;
			case 5: item = "Rippers                   "; break;
			case 6: item = "Vampires                  "; break;
			case 7: item = "Slice & Dice              "; break;
			case 8: item = "Kerenzikov  (+1 Init.)    "; break;
			case 9: item = "Sandevistan (+3 Init.)    "; break;
			case 10: item = "Other Cyberware          "; break;
			case 11: item = "Pain Editor              "; break;
			case 12: item = "Smartgun Link            "; break;
			case 13: item = "Subdermal Armor (SP 18)  "; break;
			case 14: item = "Muscle/Bone Lace (+2 BOD)"; break;
			case 15: item = "Chipware Socket          "; break;
		}
/* Scan for duplicates someday */
		cyberware[i] = item;
		printf("%s%s", item, type);
		if ((i % 2) == 0)
			if (i == numcyberware-1)
				printf("\n");
			else
				printf("\t\t");
		else
			printf("\n");
	}

/* See if this person happens to be under the influence */
	if (d10() < 4)
	{
		printf("\nCurrently on ");
		drug = d6();
		switch (drug){
			case 1: printf("Boost -- +1 Int\n"); break;
			case 2: printf("Stim -- hyperactive\n"); break;
			case 3: printf("Smash -- euphoric\n"); break;
			case 4: printf("Alcohol -- drunk\n"); break;
			case 5: printf("Dorph -- ignore stun/shock\n"); break;
			case 6: printf("Black Lace -- ignore stun/shock, +2 Cool\n"); break;
		}
	}
/* Now, determine armor and weapons */
	armor = d10();
	weapon = d10();
	if (roleint == SOLO)
	{
		armor += 3;
		weapon += 3;
	}
	if ((roleint == NOMAD) || (roleint == COP))
	{
		armor += 2;
		weapon += 2;
	}
	if (roleint == THUG)
	{
		armor += 1;
		weapon += 1;
	}
	switch (armor) {
		case 1: item = "Heavy Leather         "; break;
		case 2: item = "Armor Vest            "; break;
		case 3: item = "L.Armor Jacket        "; break;
		case 4: item = "L.Armor/Leather Pant  "; break;
		case 5: item = "M. Armor/Flack Pants  "; break;
		case 6: item = "M. Jack./Helm/L.Pant  "; break;
		case 7: item = "M. Jacket/F.Pant      "; break;
		case 8: item = "H. Jacket/L.Pant      "; break;
		case 9: item = "H. Jacket/Helm/F.Pant "; break;
		default: item= "MetalGear             "; break;
	}
	printf("\nArmor Type: %s \t", item);
	switch (weapon) {
		case 1: type = "Knife"; break;
		case 2: type = "Light Pistol"; break;
		case 3: type = "Medium Pistol"; break;
		case 4: type = "Heavy Pistol"; break;
		case 5: type = "Heavy Pistol"; break;
		case 6: type = "Light SMG"; break;
		case 7: type = "Lt. Assault R."; break;
		case 8: type = "Med. Assault R."; break;
		case 9: type = "Exotic"; break;
		default: type= "Hvy. Assault R."; break;
	}
	printf("\nWeapon Type: %s\n\n", type);

/* Print out the armor values for body parts */
	switch (armor) {
		case 1: printf("Head:0    Torso:4    R.Arm:4    L.Arm.:4 ");
			printf("  R.Leg:4    L.Leg:4\n"); break;
		case 2: printf("Head:0    Torso:10   R.Arm:0    L.Arm.:0 ");
			printf("  R.Leg:0    L.Leg:0\n"); break;
		case 3: printf("Head:0    Torso:14   R.Arm:14   L.Arm.:14");
			printf("  R.Leg:0    L.Leg:0\n"); break;
		case 4: printf("Head:0    Torso:14   R.Arm:14   L.Arm.:14");
			printf("  R.Leg:4    L.Leg:4\n"); break;
		case 5: printf("Head:0     Torso:18   R.Arm:18   L.Arm.:18");
			printf("  R.Leg:20   L.Leg:20\n"); break;
		case 6: printf("Head:20   Torso:18   R.Arm:18    L.Arm.:18");
			printf("  R.Leg:4    L.Leg:4\n"); break;
		case 7: printf("Head:0    Torso:18   R.Arm:18    L.Arm.:18");
			printf("  R.Leg:20   L.Leg:20\n"); break;
		case 8: printf("Head:0    Torso:20   R.Arm:20    L.Arm.:20");
			printf("  R.Leg:4    L.Leg:4\n"); break;
		case 9: printf("Head:20   Torso:20   R.Arm:20    L.Arm.:20");
			printf("  R.Leg:20   L.Leg:20\n"); break;
		default: printf("Head:25  Torso:25   R.Arm:25    L.Arm.:25");
			printf("  R.Leg:25   L.Leg:25\n"); break;
		}

/* Figure out the BTM */
	btm = 0;
	if (Body > 2) btm--;
	if (Body > 4) btm--;
	if (Body > 7) btm--;
	if (Body > 9) btm--;
	if (Body > 11) btm --;

/* Wound state */
	printf("\nLight:  [][][][]  Serious:[][][][]  Critical:[][][][]  ");
	printf("Mortal0:[][][][]\nMortal1:[][][][]  Mortal2:[][][][]  ");
	printf("Mortal3: [][][][]  Mortal4:[][][][]\n");
	printf("Save: %d\t\tBTM: %d\n", Body, btm);
	printf("\nOther:\n\n\n\n\n\n");

	return (0);
}


int countargs(char *argument)
{
	int number = 0;
	extern int numsolo, numnomad, numrocker,  numnetrunner;
	extern int numcorp, numtech,  nummedtech, nummedia;
	extern int numcop,  numfixer, numthug;

	number = atoi(argument+1);

	if (strncmp(argument,"s",1) == 0) numsolo += number;
	if (strncmp(argument,"o",1) == 0) numnomad += number;
	if (strncmp(argument,"r",1) == 0) numrocker += number;
	if (strncmp(argument,"n",1) == 0) numnetrunner += number;
	if (strncmp(argument,"c",1) == 0) numcorp += number;
	if (strncmp(argument,"t",1) == 0) numtech += number;
	if (strncmp(argument,"d",1) == 0) nummedtech += number;
	if (strncmp(argument,"m",1) == 0) nummedia += number;
	if (strncmp(argument,"p",1) == 0) numcop += number;
	if (strncmp(argument,"x",1) == 0) numfixer += number;
	if (strncmp(argument,"h",1) == 0) numthug += number;

	return(0);
}

int printrole(int rolenum)
{
	if (rolenum == SOLO)    printf("Solo");
	if (rolenum == NOMAD)   printf("Nomad");
	if (rolenum == ROCKER)  printf("Rocker");
	if (rolenum == NETRUNNER) printf("Netrunner");
	if (rolenum == CORP)    printf("Corporate");
	if (rolenum == TECHIE)  printf("Techie");
	if (rolenum == MEDTECH) printf("Medtechie");
	if (rolenum == MEDIA)   printf("Media");
	if (rolenum == COP)     printf("Cop");
	if (rolenum == FIXER)   printf("Fixer");
	if (rolenum == THUG)	printf("Thug");

	return(0);
}

int skillnum(int *points, int max)
{
	int temp;

	if (max < 1)
	{
		fprintf(stderr, "\nYou can't have a maximum less than 1\n");
		exit (0);
	}

	if (*points < 2)
	{
		return (*points);
	}
	temp = rand() % max + 1;
	*points = *points - temp;
	while (*points < 0)
	{
		temp = temp - 1;
		*points = *points + 1;
	}
	return (temp);
}

int help()
{
	fprintf(stderr, "\nCPNPC 1.1--Cyberpunk 2020 NPC Generator--");
	fprintf(stderr, "Todd Bradley--January 1992");
	fprintf(stderr, "\n\nUsage: cpnpc role num [role num]");
	fprintf(stderr, "\nwhere role is");
	fprintf(stderr, "\n\t\ts\tSolo -- combat jockey");
	fprintf(stderr, "\n\t\to\tNomad -- road warrior");
	fprintf(stderr, "\n\t\tr\tRocker -- charismatic leader");
	fprintf(stderr, "\n\t\tn\tNetrunner -- computer hacker");
	fprintf(stderr, "\n\t\tc\tCorporate -- business raider");
	fprintf(stderr, "\n\t\tt\tTechie -- cybernerd");
	fprintf(stderr, "\n\t\td\tMedtechie -- doctor or medic");
	fprintf(stderr, "\n\t\tm\tMedia -- newsperson");
	fprintf(stderr, "\n\t\tp\tCop -- ultramodern police officer");
	fprintf(stderr, "\n\t\tx\tFixer -- underworld businessperson");
	fprintf(stderr, "\n\t\th\tThug -- common violent citizen");
	fprintf(stderr, "\nand num is how many of that type of character you want");
	fprintf(stderr, "\n\nFor example: 'cpnpc s8 n10' to make ");
	fprintf(stderr, "8 Solos and 10 Netrunners\n\nSee the documentation");
	fprintf(stderr, " for full credits and copyright notice.\n");
	exit (0);
	return (0);
}

int d6(void)
{
	int die;
	die = rand() % 6 + 1;
	return die;
}

int d10(void)
{
	int die;
	die = rand() % 10 + 1;
	return die;
}


checkstats()
/* This procedure checks each one of the NPC's stats and makes
   sure they are between 2 and 10 */

{
   if (Int < 2)   Int = 2;
   if (Int > 10)  Int = 10;
   if (Ref < 2)   Ref = 2;
   if (Ref > 10)  Ref = 10;
   if (Tech < 2)  Tech = 2;
   if (Tech > 10) Tech = 10;
   if (Cool < 2)  Cool = 2;
   if (Cool > 10) Cool = 10;
   if (Attr < 2)  Attr = 2;
   if (Attr > 10) Attr = 10;
   if (Luck < 2)  Luck = 2;
   if (Luck > 10) Luck = 10;
   if (MA < 2)    MA = 2;
   if (MA > 10)   MA = 10;
   if (Body < 2)  Body = 2;
   if (Body > 10) Body = 10;
   if (Emp < 2)   Emp = 2;
   if (Emp > 10)  Emp = 10;

   return (0);
}

/* cpnpc.c -- This is the main file for the Cyberpunk NPC generator

	Version 1.1 written by Todd Bradley, January 2, 1992

	You may use the cpnpc program and modify the source code
	for your own purposes given that the following conditions
	are met:

	1.) this notice must remain in the source code
	2.) you may not sell the program or source code

	I would appreciate any new versions you make based on this
	code.  My Internet address is bradleyt@spot.colorado.edu
*/
